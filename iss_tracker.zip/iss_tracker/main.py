import requests
from datetime import datetime
import time

MY_EMAIL = "___YOUR_EMAIL_HERE____"
MY_PASSWORD = "___YOUR_PASSWORD_HERE___"
MY_LAT = 0# Your latitude
MY_LONG = 0 # Your longitude
iss_latitude=0
yellow = "\033[33m"  # Yellow text
iss_longitude=0
green = "\033[32m"  # Green text
white= "\033[0m"
red = "\033[31m"
Blue= "\033[34m"
Magenta="\033[35m"
Cyan= "\033[36m"



def is_iss_overhead():
    global iss_latitude,iss_longitude,MY_LAT,MY_LONG
    response = requests.get(url="http://api.open-notify.org/iss-now.json")
    response.raise_for_status()
    data = response.json()

    iss_latitude = float(data["iss_position"]["latitude"])
    iss_longitude = float(data["iss_position"]["longitude"])

    #Your position is within +5 or -5 degrees of the iss position.
    if MY_LAT-5 <= iss_latitude <= MY_LAT+5 and MY_LONG-5 <= iss_longitude <= MY_LONG+5:
        return True


def is_night():
    global MY_LAT,MY_LONG
    parameters = {
        "lat": MY_LAT,
        "lng": MY_LONG,
        "formatted": 0,
    }
    response = requests.get("https://api.sunrise-sunset.org/json", params=parameters)
    response.raise_for_status()
    data = response.json()
    sunrise = int(data["results"]["sunrise"].split("T")[1].split(":")[0])
    sunset = int(data["results"]["sunset"].split("T")[1].split(":")[0])

    time_now = datetime.now().hour

    if time_now >= sunset or time_now <= sunrise:
        return True

def user_enter():
    global MY_LAT,MY_LONG
    try:
        MY_LAT=float(input(f"{Cyan}Enter the latitude of your current location:"))
        MY_LONG=float(input("Enter the longitude of your current location:"))
        headers = {
                'User-Agent': 'ISS Tracker/1.0'
        }
        params = {
                'lat': MY_LAT,
                'lon': MY_LONG,
                'format': 'json'
        }
        req2=requests.get(url = f"https://nominatim.openstreetmap.org/reverse",params=params, headers=headers)
        req2.raise_for_status()
        d=req2.json()
        city=d["display_name"].split(",")[1]
        print(f"Based on your input,your Current Location is{green}{city}")
    except:
        print(f"{red}Wrong input, Please re-check your entry and try again.{white}")
        user_enter()

def iss_location():
    global iss_latitude, iss_longitude
    headers = {
        'User-Agent': 'ISS Tracker/1.0'
    }
    params = {
        'lat': iss_latitude,
        'lon': iss_longitude,
        'format': 'json'
    }
    req3 = requests.get(url=f"https://nominatim.openstreetmap.org/reverse", params=params, headers=headers)
    req3.raise_for_status()
    d = req3.json()
    try:
        city = d["display_name"].split(",")[1]
        return city
    except:
        return "Oceanic Region"
##################################################################
print(f"""{yellow}
'####::'######:::'######:::::'########:'########:::::'###:::::'######::'##:::'##:'########:'########::
. ##::'##... ##:'##... ##::::... ##..:: ##.... ##:::'## ##:::'##... ##: ##::'##:: ##.....:: ##.... ##:
: ##:: ##:::..:: ##:::..:::::::: ##:::: ##:::: ##::'##:. ##:: ##:::..:: ##:'##::: ##::::::: ##:::: ##:
: ##::. ######::. ######:::::::: ##:::: ########::'##:::. ##: ##::::::: #####:::: ######::: ########::
: ##:::..... ##::..... ##::::::: ##:::: ##.. ##::: #########: ##::::::: ##. ##::: ##...:::: ##.. ##:::
: ##::'##::: ##:'##::: ##::::::: ##:::: ##::. ##:: ##.... ##: ##::: ##: ##:. ##:: ##::::::: ##::. ##::
'####:. ######::. ######:::::::: ##:::: ##:::. ##: ##:::: ##:. ######:: ##::. ##: ########: ##:::. ##:
....:::......::::......:::::::::..:::::..:::::..::..:::::..:::......:::..::::..::........::..:::::..::
""")
print(f"{green}Welcome to International Space Station Tracker.")
print("Created By:Hari Ravendran\n\n")
print(f"{yellow}Tips:You can use latlong.net or google maps to find the latitude and longitude of your current location.")

user_enter()


while True:

    print(f"\n{yellow}Updating ISS Location...")
    try:
        if is_iss_overhead() and is_night():

            print(f"{green}Look Up👆\n\nThe ISS is above you in the sky. Location:{iss_location()} | Loading updates...")
        elif is_iss_overhead() and is_night()!=True:
            print(f"{green}International Space Station is Currently above you. Location:{iss_location()}, but not visible in day time. | Loading updates...")
        else:
            print(f"{green}International Space Station is Currently at Latitude:{iss_latitude} & Longitude:{iss_longitude} | Location:{iss_location()} | Loading updates...")
    except:
        print(f"{red}ISS Connection lost, please wait...")
    time.sleep(60)


